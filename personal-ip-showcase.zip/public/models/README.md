# 3D model asset placeholder

Place a real, rigged `tabby-fuku.glb` file in this folder to enable model loading.
The demo intentionally does **not** include or pretend to include a 3D character model.
The supplied image remains the honest fallback preview until you add your own GLB.
For real animation playback, the GLB should include named clips (e.g. `待機`, `眨眼`, `揮手`, `跳躍`) or update the mapping in `src/components/Stage.tsx`.
