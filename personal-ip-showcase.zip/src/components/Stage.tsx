import { Suspense, useEffect, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { ContactShadows, OrbitControls, useGLTF, Html } from '@react-three/drei'
import * as THREE from 'three'
import { character } from '../data/character'

function Model({ animation }: { animation: string }) {
  const gltf = useGLTF(character.modelPath)
  const group = useRef<THREE.Group>(null)
  const mixer = useRef<THREE.AnimationMixer | null>(null)
  useEffect(() => {
    if (!gltf.scene) return
    mixer.current = new THREE.AnimationMixer(gltf.scene)
    const clip = gltf.animations.find(a => a.name.toLowerCase().includes(animation.toLowerCase()))
    if (clip) mixer.current.clipAction(clip).reset().play()
    return () => { mixer.current?.stopAllAction() }
  }, [gltf, animation])
  useFrame((_, delta) => { mixer.current?.update(delta) })
  return <group ref={group}><primitive object={gltf.scene} scale={1.5} position={[0, -1.2, 0]} /></group>
}
function PlaceholderStage({ animation }: { animation: string }) {
  const group = useRef<THREE.Group>(null)
  useFrame(({ clock }, delta) => {
    if (!group.current) return
    const t = clock.getElapsedTime()
    group.current.position.y = Math.sin(t * 1.2) * 0.045
    group.current.rotation.y += delta * (animation === '跳躍' ? 0.75 : 0.12)
  })
  return <group ref={group}>
    <mesh position={[0, -1.08, 0]}><cylinderGeometry args={[0.88, 1.02, 0.14, 64]} /><meshStandardMaterial color="#e6d7c2" roughness={0.75} /></mesh>
    <mesh position={[0, -0.99, 0]}><cylinderGeometry args={[0.7, 0.82, 0.05, 64]} /><meshStandardMaterial color="#c4a989" roughness={0.5} /></mesh>
    <mesh position={[0, 0, 0]}><sphereGeometry args={[0.66, 32, 32]} /><meshStandardMaterial color="#e8d8c3" wireframe roughness={0.7} /></mesh>
    <mesh position={[0, 0, 0.67]}><planeGeometry args={[1.38, 1.72]} /><meshBasicMaterial transparent opacity={0} /></mesh>
    <Html center transform position={[0, 0.02, 0.04]} distanceFactor={2.35} style={{ pointerEvents: 'none' }}>
      <div className={`avatar-billboard ${animation === '眨眼' ? 'blink' : ''} ${animation === '揮手' ? 'wave' : ''} ${animation === '跳躍' ? 'jump' : ''}`}>
        <img src={character.image} alt="" />
      </div>
    </Html>
  </group>
}
function Scene({ animation }: { animation: string }) {
  const { gl } = useThree()
  useEffect(() => { gl.setClearColor('#f7f1e7', 0) }, [gl])
  return <>
    <ambientLight intensity={1.65} />
    <directionalLight position={[3, 5, 4]} intensity={2.2} />
    <directionalLight position={[-3, 2, -2]} intensity={0.7} color="#f4c9a0" />
    <Suspense fallback={<Html center><span className="scene-loading">正在載入角色…</span></Html>}>
      {character.use3DModel && <Model animation={animation} />}
    </Suspense>
    <PlaceholderStage animation={animation} />
    <ContactShadows position={[0, -1.17, 0]} opacity={0.25} scale={4} blur={2.5} far={2.5} />
    <OrbitControls enablePan={false} minDistance={3} maxDistance={7} minPolarAngle={Math.PI / 3.5} maxPolarAngle={Math.PI / 1.8} />
  </>
}
export default function Stage({ animation }: { animation: string }) {
  const [webgl, setWebgl] = useState(true)
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas')
      setWebgl(!!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))))
    } catch { setWebgl(false) }
  }, [])
  if (!webgl) return <div className="stage-fallback"><img src={character.image} alt={`${character.name}角色插畫`} /><p>此裝置不支援 WebGL，改以原始插畫展示。</p></div>
  return <div className="three-stage">
    <Canvas camera={{ position: [0, 0.25, 4.7], fov: 38 }} dpr={[1, 1.7]} aria-label="可拖曳旋轉的角色展示場景">
      <Scene animation={animation} />
    </Canvas>
    <div className="stage-hint">拖曳旋轉 · 滾輪縮放</div>
  </div>
}