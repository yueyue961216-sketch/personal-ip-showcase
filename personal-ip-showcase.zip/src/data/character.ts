export type CharacterConfig = {
  name: string; romanized: string; tagline: string; intro: string; image: string
  modelPath: string; use3DModel: boolean; colors: { name: string; hex: string; role: string }[]
  traits: string[]; story: string; design: string; accessories: string[]
  quotes: string[]; animations: string[]; socials: { label: string; href: string }[]
}
export const character: CharacterConfig = {
  name: '虎斑小福', romanized: 'TABBY FUKU',
  tagline: '把日常的小事，變成值得收藏的幸運。',
  intro: '一位帶著麻將符牌與紅繩的小小守福使者。好奇、熱心，總能在平凡日子裡找到一點好運。',
  image: '/assets/tabby-catgirl.jpg',
  // Replace with a real, rigged .glb/.gltf file. Until then, the interface intentionally uses the supplied 2D artwork.
  modelPath: '/models/tabby-fuku.glb', use3DModel: false,
  colors: [
    { name: '暖米白', hex: '#F7F1E7', role: '背景與服裝' },
    { name: '虎斑棕', hex: '#9A6847', role: '毛色與主視覺' },
    { name: '墨茶', hex: '#302923', role: '深色線條' },
    { name: '朱砂紅', hex: '#B83E35', role: '符牌與繩結' },
    { name: '玉石綠', hex: '#315E4D', role: '內搭與點綴' }
  ],
  traits: ['好奇心旺盛', '嘴硬心軟', '迷信一點點', '超愛收集小物'],
  story: '小福住在城市邊緣一間老茶屋的屋頂上。她相信每個人都有自己的幸運符，因此總把撿到的小物整理成護身掛飾，悄悄送給需要鼓勵的人。',
  design: '以虎斑貓的條紋作為辨識核心，融合東方結繩、麻將符牌與簡潔的街頭服飾。暖米白降低視覺重量，朱砂紅與玉石綠建立鮮明記憶點。',
  accessories: ['「中」字符牌髮飾', '紅繩中國結', '麻將耳墜', '尾巴幸運吊飾'],
  quotes: ['今天也要把好運分你一點！', '欸？這個小東西看起來很有緣。', '不用很厲害，也可以成為別人的幸運。', '等一下——先讓我摸摸看這個符牌！'],
  animations: ['待機', '眨眼', '揮手', '跳躍'],
  socials: [{ label: 'Instagram', href: 'https://instagram.com/' }, { label: 'ArtStation', href: 'https://www.artstation.com/' }, { label: 'Email', href: 'mailto:hello@example.com' }]
}