import { useState } from 'react'
import { ArrowDownRight, ArrowUpRight, Check, Copy, Heart, MessageCircle, Rotate3D, Sparkles } from 'lucide-react'
import Stage from './components/Stage'
import { character } from './data/character'

type View = '正面' | '側面' | '背面'
export default function App() {
  const [view, setView] = useState<View>('正面')
  const [animation, setAnimation] = useState('待機')
  const [quote, setQuote] = useState(character.quotes[0])
  const [copied, setCopied] = useState('')
  const [showDialogue, setShowDialogue] = useState(false)
  const copyColor = async (hex: string) => {
    try { await navigator.clipboard.writeText(hex); setCopied(hex); window.setTimeout(() => setCopied(''), 1400) }
    catch { setCopied('error') }
  }
  const randomQuote = () => {
    const options = character.quotes.filter(q => q !== quote)
    setQuote(options[Math.floor(Math.random() * options.length)] || character.quotes[0])
    setShowDialogue(true)
  }
  return <main>
    <nav className="topbar"><a className="wordmark" href="#home"><span className="brand-mark">福</span> FUKU / IP STUDIO</a><div className="nav-links"><a href="#profile">角色設定</a><a href="#colors">色彩系統</a><a href="#motion">互動展示</a></div><a className="nav-cta" href="#contact">聯絡合作 <ArrowUpRight size={15}/></a></nav>
    <section className="hero section-wrap" id="home">
      <div className="hero-copy">
        <p className="eyebrow"><span className="eyebrow-dot"/> ORIGINAL CHARACTER · 001</p>
        <h1>{character.name}<span className="title-period">。</span></h1>
        <p className="romanized">{character.romanized} <span>— PERSONAL IP</span></p>
        <h2>{character.tagline}</h2>
        <p className="intro">{character.intro}</p>
        <div className="hero-actions"><a className="button-dark" href="#profile">探索角色 <ArrowDownRight size={16}/></a><button className="button-light" onClick={randomQuote}><MessageCircle size={16}/> 聽聽小福說</button></div>
        {showDialogue && <div className="speech-inline"><span>小福說</span>{quote}</div>}
        <div className="hero-meta"><div><strong>01</strong><span>角色編號</span></div><div><strong>2D / 3D</strong><span>展示形式</span></div><div><strong>2026</strong><span>創作年份</span></div></div>
      </div>
      <div className="hero-visual"><div className="visual-note note-top">CHARACTER<br/>DESIGN SHEET <span>↘</span></div><div className="hero-orbit orbit-one"/><div className="hero-orbit orbit-two"/><div className="hero-art-frame"><img src={character.image} alt={`${character.name}全身角色設計`} /></div><div className="vertical-label">LUCK · KINDNESS · CURIOSITY</div><div className="visual-index">FIG. 01 <span>— TABBY CATGIRL</span></div></div>
    </section>
    <section className="marquee-strip" aria-label="角色關鍵字"><span>SMALL LUCK, EVERY DAY</span><i>✳</i><span>DESIGNED WITH HEART</span><i>✳</i><span>SMALL LUCK, EVERY DAY</span><i>✳</i><span>DESIGNED WITH HEART</span></section>
    <section className="section-wrap profile-section" id="profile">
      <div className="section-heading"><div><p className="eyebrow">01 / CHARACTER PROFILE</p><h2>關於小福<span>，</span></h2></div><p className="section-aside">A LITTLE LUCK<br/>IN YOUR POCKET.</p></div>
      <div className="profile-grid"><div className="profile-image"><img src={character.image} alt="虎斑小福角色插畫"/><span className="image-caption">FIG 01 — FULL BODY DESIGN</span></div><div className="profile-details"><p className="detail-kicker">THE STORY</p><h3>把好運，<br/>偷偷分給你。</h3><p>{character.story}</p><div className="detail-rule"/><p className="detail-kicker">PERSONALITY</p><div className="trait-list">{character.traits.map(t => <span key={t}>{t}</span>)}</div><div className="detail-rule"/><p className="detail-kicker">DESIGN CONCEPT</p><p>{character.design}</p><p className="detail-kicker accessories-label">SIGNATURE ACCESSORIES</p><div className="accessory-list">{character.accessories.map((a, i) => <div key={a}><span>0{i+1}</span>{a}</div>)}</div></div></div>
    </section>
    <section className="color-section" id="colors"><div className="section-wrap"><div className="section-heading"><div><p className="eyebrow">02 / COLOR SYSTEM</p><h2>小福的色彩<span>。</span></h2></div><p className="section-aside">PALETTE STUDY<br/>01—05</p></div><p className="section-intro">以溫暖、沉穩的基底搭配少量高辨識度色彩，讓角色在不同媒介中都保有一致的視覺語言。</p><div className="palette-grid">{character.colors.map((c, i) => <article className="swatch-card" key={c.hex}><button className="swatch" style={{ backgroundColor: c.hex }} onClick={() => copyColor(c.hex)} aria-label={`複製${c.name}色碼 ${c.hex}`}><span>{copied === c.hex ? <Check/> : <Copy/>}</span></button><div className="swatch-meta"><div><span className="swatch-number">0{i+1}</span><strong>{c.name}</strong></div><button onClick={() => copyColor(c.hex)} className="hex-button">{copied === c.hex ? '已複製' : c.hex}</button></div><p>{c.role}</p></article>)}</div></div></section>
    <section className="section-wrap motion-section" id="motion"><div className="section-heading"><div><p className="eyebrow">03 / INTERACTIVE SHOWCASE</p><h2>轉個角度看看<span>。</span></h2></div><div className="round-icon"><Rotate3D size={20}/></div></div><p className="section-intro">拖曳畫面探索展示空間，切換動作與表情。正式 3D 模型可直接替換示範資產。</p><div className="showcase-grid"><div className="showcase-stage"><div className="stage-topline"><span>LIVE PREVIEW / 001</span><span><i className="live-dot"/> DEMO MODE</span></div><Stage animation={animation}/><div className="stage-bottomline"><span>{character.name} / CHARACTER VIEWER</span><span>R3F · THREE.JS</span></div></div><aside className="control-panel"><p className="detail-kicker">VIEW CONTROL</p><h3>觀察角色</h3><div className="view-switch">{(['正面','側面','背面'] as View[]).map(v => <button className={view === v ? 'active' : ''} onClick={() => setView(v)} key={v}>{v}</button>)}</div><p className="control-note">{view === '正面' ? '正面視角 · 角色主視覺' : view === '側面' ? '側面視角 · 請以正式模型檢視輪廓' : '背面視角 · 請以正式模型檢視服裝細節'}</p><div className="detail-rule"/><p className="detail-kicker">MOTION & EXPRESSION</p><h3>選擇動作</h3><div className="motion-options">{character.animations.map(a => <button className={animation === a ? 'active' : ''} key={a} onClick={() => setAnimation(a)}><span className="motion-symbol">{a === '待機' ? '◌' : a === '眨眼' ? '⌒' : a === '揮手' ? '✳' : '↑'}</span>{a}<span className="motion-state">{animation === a ? 'SELECTED' : 'PLAY'}</span></button>)}</div><div className="asset-notice"><Sparkles size={16}/><p><strong>資產提示</strong><br/>目前使用 2D 角色插畫與簡易展示台作為備援。加入已綁定骨架、含動畫的 GLB 後，即可播放真實模型動畫。</p></div></aside></div></section>
    <section className="quote-section"><div className="quote-decoration">“</div><p className="eyebrow">04 / A WORD FROM FUKU</p><blockquote>{quote}</blockquote><button onClick={randomQuote}>再聽一句 <ArrowUpRight size={15}/></button><span className="quote-stamp">福</span></section>
    <footer id="contact"><div className="footer-main section-wrap"><div><p className="eyebrow">LET'S MAKE SOMETHING NICE</p><h2>讓好點子，<br/>成為下一個角色。</h2><a className="footer-email" href="mailto:hello@example.com">hello@example.com <ArrowUpRight size={17}/></a></div><div className="footer-links"><p>FOLLOW THE STUDIO</p>{character.socials.map(s => <a href={s.href} target={s.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer" key={s.label}>{s.label}<ArrowUpRight size={14}/></a>)}</div><div className="footer-mark"><span>福</span><p>GOOD LUCK<br/>GOES AROUND.</p></div></div><div className="footer-bottom section-wrap"><span>© 2026 FUKU IP STUDIO. ALL RIGHTS RESERVED.</span><span>MADE WITH <Heart size={12} fill="currentColor"/> AND A LITTLE LUCK.</span></div></footer>
  </main>
}